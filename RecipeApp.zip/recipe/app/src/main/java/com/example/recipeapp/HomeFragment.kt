package com.example.recipeapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HomeFragment : Fragment() {

    private lateinit var viewModel: RecipeViewModel
    private lateinit var verticalAdapter: RecipeAdapter
    private lateinit var horizontalAdapter: RecipeAdapter


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        viewModel = ViewModelProvider(this)[RecipeViewModel::class.java]

        val verticalRecyclerView = view.findViewById<RecyclerView>(R.id.vertical_recycler_view)
        verticalRecyclerView.layoutManager = LinearLayoutManager(context)
        verticalAdapter = RecipeAdapter(emptyList(),1)
        verticalRecyclerView.adapter = verticalAdapter

        val horizontalRecyclerView = view.findViewById<RecyclerView>(R.id.horizontal_recycler_view)
        horizontalRecyclerView.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        horizontalAdapter = RecipeAdapter(emptyList(),2)
        horizontalRecyclerView.adapter = horizontalAdapter

        viewModel.recipes.observe(viewLifecycleOwner) { recipes ->
            verticalAdapter.updateRecipes(recipes,1)
            horizontalAdapter.updateRecipes(recipes,2)
        }

        viewModel.getRecipes()


    }


}