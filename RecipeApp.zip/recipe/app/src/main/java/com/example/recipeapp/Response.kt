package com.example.recipeapp

data class Response(
    val meals: List<Meal>
)